<span class="weibo">
	<wb:follow-button uid="<?php echo zm_get_option('weibo_id'); ?>" width="67" height="24" ></wb:follow-button>
</span>