window._bd_share_config = {
	"common": {
		"bdSnsKey": {},
		"bdText": "",
		"bdMini": "2",
		"bdMiniList": false,
		"bdPic": "",
		"bdStyle": "1",
		"bdSize": "16"
	},
	"share": {
		"bdSize": 16
	}
};

var ishttps = 'https:' == document.location.protocol ? true: false;

if(ishttps){
	with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'https://' + window.location.host + '/static/api/js/share.js?v=89860593.js?cdnversion=' + ~ ( - new Date() / 36e5)];
}else{
	with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://' + window.location.host + '/static/api/js/share.js?v=89860593.js?cdnversion=' + ~ ( - new Date() / 36e5)];
}